 * Copyright (c) 1988, 1990 Regents of the University of California.
 * All rights reserved.
