 * Copyright (c) 1992-2016 by Mike Gleason.
 * All rights reserved.
